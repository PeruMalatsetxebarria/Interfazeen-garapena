﻿using Microsoft.AspNetCore.Mvc;
using REST_API.Services;
using REST_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace REST_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UpeltegiaController : Controller
    {
        private readonly IUpeltegiaService _upeltegiaService;
        public UpeltegiaController(IUpeltegiaService upeltegiaService)
        {
            _upeltegiaService = upeltegiaService;
        }
        // GET: api/Upeltegia
        [HttpGet]
        public async Task<ActionResult<List<Upeltegia>>> GetUpeltegiak()
        {
            return await _upeltegiaService.GetUpeltegiak();
        }
    }
}
