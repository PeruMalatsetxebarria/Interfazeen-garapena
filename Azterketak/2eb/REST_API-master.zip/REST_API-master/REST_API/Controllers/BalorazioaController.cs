﻿using Microsoft.AspNetCore.Mvc;
using REST_API.Services;
using REST_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace REST_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BalorazioaController : Controller
    {
        private readonly IBalorazioaService _balorazioaService;
        public BalorazioaController(IBalorazioaService balorazioaService)
        {
            _balorazioaService = balorazioaService;
        }
        // GET: api/Balorazioa
        [HttpGet]
        public async Task<ActionResult<List<Balorazioa>>> GetBalorazioak()
        {
            return await _balorazioaService.GetBalorazioak();
        }
        // GET: api/Balorazioa/1
        [HttpGet("{id}")]
        public async Task<ActionResult<List<Balorazioa>>> GetBalorazioa(int id)
        {
            return await _balorazioaService.GetBalorazioa(id);
        }
        // POST: api/Balorazioa
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Balorazioa>> PostBalorazioa(Balorazioa balorazioa)
        {
            await _balorazioaService.PostBalorazioa(balorazioa);
            return balorazioa;
        }
    }
}
