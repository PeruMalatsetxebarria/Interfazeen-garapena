﻿using Microsoft.EntityFrameworkCore;
using REST_API.Data;
using REST_API.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace REST_API.Services
{
    public class BalorazioaService : IBalorazioaService
    {
        private readonly WineShopDbContext _context;

        public BalorazioaService(WineShopDbContext context)
        {
            _context = context;
        }
        public async Task<List<Balorazioa>> GetBalorazioak()
        {
            return await _context.Balorazioa.ToListAsync();
        }
        public async Task<List<Balorazioa>> GetBalorazioa(int id)
        {
            return await _context.Balorazioa
                .Where(a => a.UpeltegiaId == id)
                .ToListAsync();
        }
        public async Task PostBalorazioa(Balorazioa balorazioa)
        {
            _context.Balorazioa.Add(balorazioa);
            await _context.SaveChangesAsync();
        }
    }
}
