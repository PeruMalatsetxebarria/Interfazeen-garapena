﻿using Microsoft.EntityFrameworkCore;
using REST_API.Data;
using REST_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace REST_API.Services
{
    public class UpeltegiaService : IUpeltegiaService
    {
        private readonly WineShopDbContext _context;

        public UpeltegiaService(WineShopDbContext context)
        {
            _context = context;
        }
        public async Task<List<Upeltegia>> GetUpeltegiak()
        {
            return await _context.Upeltegia.ToListAsync();
        }
    }
}
