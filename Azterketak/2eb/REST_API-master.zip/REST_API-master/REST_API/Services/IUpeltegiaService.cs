﻿using REST_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace REST_API.Services
{
    public interface IUpeltegiaService
    {
        Task<List<Upeltegia>> GetUpeltegiak();
    }
}